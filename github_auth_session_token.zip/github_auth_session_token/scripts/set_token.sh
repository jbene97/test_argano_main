export SES_TOKEN_PRV_KEY=`base64 -i /Users/fvass/.oci/sessions/tf_ion5/oci_api_key.pem`
export SES_TOKEN=`base64 -i /Users/fvass/.oci/sessions/tf_ion5/token`
export FINGERPRINT="6c:31:ec:8f:63:3f:4b:94:b3:14:44:ed:37:1f:15:04"
export TENANCY_OCID="ocid1.tenancy.oc1..aaaaaaaaz3zvzfb4afndqhyljo75yoat5azx6yw5hppwxqv3felvg3flex4q"
export TF_VAR_REGION="eu-frankfurt-1"
